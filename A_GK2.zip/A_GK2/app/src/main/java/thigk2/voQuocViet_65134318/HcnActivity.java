package thigk2.voQuocViet_65134318;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HcnActivity extends AppCompatActivity {

    EditText editTextNum1, editTextNum2, editTextResult;
    Button btnCV, btnDT;

    void TimDieuKien() {
        editTextNum1 = (EditText) findViewById(R.id.edtNum1);
        editTextNum2 = (EditText) findViewById(R.id.edtNum2);
        editTextResult = (EditText) findViewById(R.id.edtResult);
        btnCV = (Button) findViewById(R.id.btnChuViHCN);
        btnDT = (Button) findViewById(R.id.btnDienTichHCN);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_hcn);
        TimDieuKien();
    }

    public void XuLyCV(View v) {
        try {
            String strA = editTextNum1.getText().toString();
            String strB = editTextNum2.getText().toString();

            float num_a = Float.parseFloat(strA);
            float num_b = Float.parseFloat(strB);

            // Chu vi
            float sum = (num_a + num_b) * 2;

            String strSum = String.valueOf(sum);
            // Display
            editTextResult.setText(strSum);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Vui lòng nhập số hợp lệ", Toast.LENGTH_SHORT).show();
            editTextResult.setText("Lỗi dữ liệu");
        }
    }

    public void XuLyDT(View v) {
        try {
            String strA = editTextNum1.getText().toString();
            String strB = editTextNum2.getText().toString();

            float num_a = Float.parseFloat(strA);
            float num_b = Float.parseFloat(strB);

            // Dien tich
            float dienTichHCN = num_a * num_b; // Tong cua 2 so Nguyen

            String strDiv = String.valueOf(dienTichHCN);
            // Display
            editTextResult.setText(strDiv);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Vui lòng nhập số nguyên hợp lệ", Toast.LENGTH_SHORT).show();
            editTextResult.setText("Lỗi dữ liệu");
        }
    }
}