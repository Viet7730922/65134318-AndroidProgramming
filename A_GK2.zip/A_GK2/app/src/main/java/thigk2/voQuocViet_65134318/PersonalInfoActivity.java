package thigk2.voQuocViet_65134318;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PersonalInfoActivity extends AppCompatActivity {

    private ImageView imgProfile;
    private TextView tvName, tvStudentId, tvHobby;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_personal_info);
        initViews();
        displayStudentInfo();
    }

    private void initViews() {
        imgProfile = findViewById(R.id.imgProfile);
        tvName = findViewById(R.id.tvName);
        tvStudentId = findViewById(R.id.tvStudentId);
        tvHobby = findViewById(R.id.tvHobby);
    }

    private void displayStudentInfo() {
        // Bạn có thể thay thế bằng dữ liệu thật từ Intent hoặc Database
        tvName.setText("Võ Quốc Việt");
        tvStudentId.setText("MSSV: 65134318");
        tvHobby.setText("Lập trình Android, Lập trình Java");
         imgProfile.setImageResource(R.drawable.sinh_vien);
    }
}