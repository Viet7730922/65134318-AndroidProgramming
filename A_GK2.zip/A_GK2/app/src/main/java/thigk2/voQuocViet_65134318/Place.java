package thigk2.voQuocViet_65134318;

public class Place {
    private String name;
    private String address;
    private int imageResId; // Sử dụng ID ảnh từ thư mục drawable

    public Place(String name, String address, int imageResId) {
        this.name = name;
        this.address = address;
        this.imageResId = imageResId;
    }

    // Getters
    public String getName() { return name; }
    public String getAddress() { return address; }
    public int getImageResId() { return imageResId; }
}
