package thigk2.voQuocViet_65134318;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void ChucNangMot(View v) {
        Intent iManHinh1 = new Intent(this, HcnActivity.class);
        startActivity(iManHinh1);
    }
    public void ChucNangHai(View v) {
        Intent iManHinh2 = new Intent(this, CityVNActivity.class);
        startActivity(iManHinh2);
    }

    public void ChucNangBa(View v) {
        Intent iManHinh2 = new Intent(this, NhaTrangTravelPlaceActivity.class);
        startActivity(iManHinh2);
    }

    public void ChucNangBon(View v) {
        Intent iManHinh4 = new Intent(this, PersonalInfoActivity.class);
        startActivity(iManHinh4);
    }
}