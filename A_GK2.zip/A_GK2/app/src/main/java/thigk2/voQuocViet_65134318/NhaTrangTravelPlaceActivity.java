package thigk2.voQuocViet_65134318;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class NhaTrangTravelPlaceActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private PlaceAdapter adapter;
    private List<Place> placeList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_nha_trang_travel_place);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Tạo dữ liệu giả lập
        placeList = new ArrayList<>();
//        placeList.add(new Place("Tháp Bà Ponagar", "Đường 2/4, Vĩnh Phước", R.drawable.nt1));
//        placeList.add(new Place("VinWonders Nha Trang", "Đảo Hòn Tre", R.drawable.nt2));
//        placeList.add(new Place("Chùa Long Sơn", "Số 20 Đường 23/10", R.drawable.nt3));
//        placeList.add(new Place("Viện Hải dương học", "Số 1 Cầu Đá", R.drawable.nt4));

        // Thiết lập Adapter
        adapter = new PlaceAdapter(placeList);
        recyclerView.setAdapter(adapter);
    }
}